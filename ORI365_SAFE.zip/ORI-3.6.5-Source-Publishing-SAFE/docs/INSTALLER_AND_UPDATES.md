# ORI Windows installer and update contract

## Distribution

- Build the application with PyInstaller in one-folder mode. The bundle includes the Python runtime and collected Python packages; users do not install Python, Java or Node.js.
- Wrap the complete `dist/ORI` payload in the Inno Setup `ORI-Setup-x.y.z.exe` installer.
- Install per-user at `%LOCALAPPDATA%\Programs\ORI`. Setup must not request administrator rights.
- The installer creates a Start Menu shortcut, offers an optional desktop shortcut, and registers a normal Windows uninstall entry.

## Persistent user data

Program files live in the install directory. Credentials, preferences and memory live separately under `%LOCALAPPDATA%\ORI`:

- `config/api_keys.json`
- `memory/long_term.json`
- `downloads`, `screenshots`, `logs`, and updater state

The application migrates existing portable config and memory once, without overwriting newer user data. Uninstall removes the installed program and shortcuts, but deliberately keeps this data. The Settings uninstall note explains this.

## In-app update flow

1. **Check for Updates** queries the latest GitHub release metadata only. It never downloads.
2. **Download Update** downloads the matching `ORI-Setup-x.y.z.exe` and SHA-256 sidecar after the user clicks. Settings shows the real downloaded byte count, total size and percentage. The installer is not offered for installation until the checksum matches.
3. **Open Update Assistant** asks before closing ORI. A separate Windows Forms assistant opens in its own STA PowerShell process and remains visible while the update runs.
4. The assistant starts the existing installation backend in a hidden child process. The backend waits up to 25 seconds for ORI to exit, ends lingering processes from the install directory, backs up the current program files, rechecks the installer SHA-256 and runs the verified Inno Setup package in place. During Setup, the assistant shows a moving progress indicator rather than inventing a percentage that Inno Setup does not expose.
5. The backend verifies the installed executable, uninstaller and Windows uninstall DisplayVersion. It then exits without automatically launching ORI. The assistant enables **Launch ORI**.
6. When the user clicks **Launch ORI**, the assistant starts the installed executable with a one-time startup token, checks the reported PID, version and executable path, and verifies that the process remains alive for 15 seconds. Only after this handshake does it delete the rollback backup and mark the update complete.

If Setup fails, the backend restores the previous program files and reports the failure in the assistant. If the new ORI fails its launch check, the assistant keeps the previous program backup and enables a launch retry. The helper, transcript and rollback data live under `%LOCALAPPDATA%\ORI\updates`, outside the directory being replaced.

## One-time bootstrap for older installed versions

ORI 3.6.0 and 3.6.1 contain the earlier updater helper. Install the current official Setup manually once to receive the version-aware updater in ORI 3.6.2. After that one-time step, future updates use the in-app flow. Portable ZIP builds also require one manual Setup installation.

## Validation required for a public release

- Build and compile the installer on Windows CI.
- Run automated tests for release asset discovery, checksum verification, user-data migration, media synchronization and update helper contracts.
- Install on a clean Windows 10/11 user account with no Python, Java or Node.js installed.
- Verify first launch, API-key onboarding, audio, media, Phone Remote and user-data persistence.
- Update from an installed previous version using Check, Download, Open Update Assistant and Launch ORI; verify byte progress, Setup execution, version registration, startup handshake and rollback.
- Exercise bad checksum, interrupted download, failed setup, failed startup and rollback.
- Verify the uninstall entry, Settings uninstall flow, and user-data retention.

A successful CI package build is not a substitute for the clean-machine install/update test.
