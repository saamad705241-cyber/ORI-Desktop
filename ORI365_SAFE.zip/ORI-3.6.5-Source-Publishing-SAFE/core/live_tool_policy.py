"""Execution policy for tools exposed to the Gemini Live session.

Read-only lookups and launch requests may run in the background so the voice
conversation stays responsive. Tools that change files, settings, accounts, or
other machine state remain blocking until their result is known.
"""
from __future__ import annotations

NON_BLOCKING_TOOLS = frozenset({
    "open_app",
    "web_search",
    "current_weather",
    "weather_report",
    "desktop_overview",
    "hardware_inventory",
    "flight_finder",
    "youtube_video",
    "video_player",
    "system_status",
    "recall_memory",
})

_VALID_BEHAVIORS = frozenset({"BLOCKING", "NON_BLOCKING"})
_VALID_SCHEDULING = frozenset({"WHEN_IDLE", "INTERRUPT", "SILENT"})


def behavior_for_tool(name: str, explicit: str | None = None) -> str:
    """Return an explicit valid behavior or the conservative built-in policy."""
    requested = str(explicit or "").strip().upper()
    if requested in _VALID_BEHAVIORS:
        return requested
    return "NON_BLOCKING" if str(name or "").strip().lower() in NON_BLOCKING_TOOLS else "BLOCKING"


def scheduling_for_tool(
    name: str,
    explicit: str | None = None,
    behavior: str | None = None,
) -> str | None:
    """Return response scheduling only for a non-blocking function call."""
    actual_behavior = behavior_for_tool(name, behavior)
    if actual_behavior != "NON_BLOCKING":
        return None
    requested = str(explicit or "").strip().upper()
    if requested in _VALID_SCHEDULING:
        return requested
    return "WHEN_IDLE"


def function_response_payload(result, scheduling: str | None = None) -> dict:
    """Build the response map expected by Gemini Live's FunctionResponse.

    Live API places ``scheduling`` inside the response payload, alongside the
    tool result. It is not a top-level FunctionResponse field.
    """
    payload = {"result": result}
    requested = str(scheduling or "").strip().upper()
    if requested in _VALID_SCHEDULING:
        payload["scheduling"] = requested
    return payload


def supports_async_live_tools(model_name: str) -> bool:
    """Whether this Live model supports asynchronous function calling.

    Gemini 3.1 Flash Live currently supports synchronous tool execution only.
    Keep all tools blocking when the model ladder falls back to that rung.
    """
    model = str(model_name or "").lower()
    return "3.1-flash-live" not in model
