param(
    [Parameter(Mandatory = $true)][int]$AppPid,
    [Parameter(Mandatory = $true)][string]$InstallerPath,
    [Parameter(Mandatory = $true)][string]$InstallDir,
    [Parameter(Mandatory = $true)][string]$ExpectedVersion,
    [Parameter(Mandatory = $true)][string]$LogPath,
    [Parameter(Mandatory = $true)][string]$RollbackDir,
    [Parameter(Mandatory = $true)][string]$InstallHelperPath,
    [Parameter(Mandatory = $true)][string]$BackendLogPath,
    [string]$ExpectedSha256 = ""
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$installExe = [System.IO.Path]::GetFullPath((Join-Path $InstallDir "ORI.exe"))
$script:mode = "installing"
$script:newProcess = $null
$script:launchFailed = $false
$script:backendProcess = $null
$script:transcriptStarted = $false

function Set-AssistantStatus {
    param([string]$Title, [string]$Detail, [int]$Percent = -1, [switch]$Busy)
    if ($script:statusTitle) { $script:statusTitle.Text = $Title }
    if ($script:statusDetail) { $script:statusDetail.Text = $Detail }
    if ($script:progress) {
        if ($Busy) {
            $script:progress.Style = [System.Windows.Forms.ProgressBarStyle]::Marquee
            $script:progress.MarqueeAnimationSpeed = 22
        } else {
            $script:progress.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
            $script:progress.MarqueeAnimationSpeed = 0
            $script:progress.Value = [Math]::Max(0, [Math]::Min(100, $Percent))
        }
    }
    [System.Windows.Forms.Application]::DoEvents()
}

function Read-BackendProgress {
    if (!(Test-Path -LiteralPath $BackendLogPath)) { return }
    try {
        $tailText = (Get-Content -LiteralPath $BackendLogPath -Tail 32 -ErrorAction Stop) -join "`n"
        if ([string]::IsNullOrWhiteSpace($tailText)) { return }
        if ($tailText -match "UPDATE SUCCESS") {
            Set-AssistantStatus "Update installed successfully" "ORI $ExpectedVersion is ready. Launch it when you are ready." 100
        } elseif ($tailText -match "Windows uninstall registration confirms") {
            Set-AssistantStatus "Verifying installation" "Checking the installed version and Windows app registration." 92
        } elseif ($tailText -match "Running the SHA-256-verified") {
            Set-AssistantStatus "Installing ORI $ExpectedVersion" "Windows Setup is replacing the program files. Please keep this window open." -1 -Busy
        } elseif ($tailText -match "Robocopy completed") {
            Set-AssistantStatus "Backup created" "Your previous ORI program files are protected for rollback." 38
        } elseif ($tailText -match "Waiting up to") {
            Set-AssistantStatus "Preparing your update" "Closing ORI safely and checking the installation." 18
        }
    } catch { }
}

function Quote-NativeArgument {
    param([string]$Value)
    '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function Launch-UpdatedOri {
    if ($script:mode -notin @("ready", "launch-failed")) { return }
    if (!(Test-Path -LiteralPath $installExe -PathType Leaf)) {
        Set-AssistantStatus "ORI could not be launched" "The installed ORI.exe was not found. Your previous build backup is preserved." 100
        $script:mode = "launch-failed"
        return
    }
    $script:mode = "launching"
    $script:launchButton.Enabled = $false
    $script:launchButton.Text = "STARTING ORI..."
    Set-AssistantStatus "Starting ORI $ExpectedVersion" "Waiting for ORI to report its version, process and executable path." -1 -Busy
    $token = [Guid]::NewGuid().ToString("N")
    $readyDir = Join-Path $env:LOCALAPPDATA "ORI\updates\startup"
    New-Item -ItemType Directory -Path $readyDir -Force | Out-Null
    $readyFile = Join-Path $readyDir ($token + ".ready")
    Remove-Item -LiteralPath $readyFile -Force -ErrorAction SilentlyContinue
    try {
        $script:newProcess = Start-Process -FilePath $installExe -ArgumentList @("--ori-update-token=$token") -WorkingDirectory $InstallDir -PassThru
        $deadline = (Get-Date).AddSeconds(90)
        $startup = $null
        while ((Get-Date) -lt $deadline) {
            [System.Windows.Forms.Application]::DoEvents()
            if (Test-Path -LiteralPath $readyFile) {
                try { $startup = Get-Content -LiteralPath $readyFile -Raw | ConvertFrom-Json -ErrorAction Stop; break }
                catch { }
            }
            if (!(Get-Process -Id $script:newProcess.Id -ErrorAction SilentlyContinue)) {
                throw "ORI exited before confirming startup (PID $($script:newProcess.Id))."
            }
            Start-Sleep -Milliseconds 200
        }
        if (!$startup) { throw "ORI did not confirm startup within 90 seconds." }
        if ([int]$startup.pid -ne [int]$script:newProcess.Id) { throw "The startup process ID did not match." }
        if ([string]$startup.version -ne $ExpectedVersion) { throw "ORI reported version $($startup.version), expected $ExpectedVersion." }
        if ([string]::IsNullOrWhiteSpace([string]$startup.executable)) { throw "ORI did not report its executable path." }
        $reported = [System.IO.Path]::GetFullPath([string]$startup.executable)
        if (![string]::Equals($reported, $installExe, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "ORI started from an unexpected executable path: $reported"
        }
        for ($second = 1; $second -le 15; $second++) {
            [System.Windows.Forms.Application]::DoEvents()
            if (!(Get-Process -Id $script:newProcess.Id -ErrorAction SilentlyContinue)) {
                throw "ORI closed during the 15-second stability check."
            }
            Set-AssistantStatus "ORI is starting" "Startup verified. Checking that the new session remains stable ($second/15)." -1 -Busy
            Start-Sleep -Seconds 1
        }
        Remove-Item -LiteralPath $readyFile -Force -ErrorAction SilentlyContinue
        if (Test-Path -LiteralPath $RollbackDir) {
            Remove-Item -LiteralPath $RollbackDir -Recurse -Force -ErrorAction SilentlyContinue
        }
        $script:mode = "done"
        Set-AssistantStatus "ORI $ExpectedVersion is ready" "Startup and stability checks passed. You can close this window." 100
        $script:launchButton.Text = "DONE"
        $script:launchButton.Enabled = $true
    } catch {
        if ($script:newProcess -and (Get-Process -Id $script:newProcess.Id -ErrorAction SilentlyContinue)) {
            try { Stop-Process -Id $script:newProcess.Id -Force -ErrorAction SilentlyContinue } catch { }
        }
        $script:mode = "launch-failed"
        $script:launchFailed = $true
        Set-AssistantStatus "ORI could not finish starting" "$($_.Exception.Message) Your previous program backup has been kept. You can retry Launch ORI." 100
        $script:launchButton.Text = "RETRY LAUNCH"
        $script:launchButton.Enabled = $true
    }
}

try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()
    New-Item -ItemType Directory -Path (Split-Path -Parent $LogPath) -Force | Out-Null
    Start-Transcript -Path $LogPath -Append | Out-Null
    $script:transcriptStarted = $true

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "ORI Update Assistant"
    $form.StartPosition = "CenterScreen"
    $form.ClientSize = New-Object System.Drawing.Size(540, 300)
    $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $form.MaximizeBox = $false
    $form.MinimizeBox = $true
    $form.BackColor = [System.Drawing.Color]::FromArgb(10, 14, 12)
    $form.ForeColor = [System.Drawing.Color]::FromArgb(235, 245, 239)
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 9)

    $brand = New-Object System.Windows.Forms.Label
    $brand.Text = "ORI  /  UPDATE ASSISTANT"
    $brand.Location = New-Object System.Drawing.Point(28, 24)
    $brand.Size = New-Object System.Drawing.Size(480, 28)
    $brand.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 14, [System.Drawing.FontStyle]::Bold)
    $brand.ForeColor = [System.Drawing.Color]::FromArgb(96, 255, 157)
    $form.Controls.Add($brand)

    $script:statusTitle = New-Object System.Windows.Forms.Label
    $script:statusTitle.Text = "Preparing ORI $ExpectedVersion"
    $script:statusTitle.Location = New-Object System.Drawing.Point(30, 78)
    $script:statusTitle.Size = New-Object System.Drawing.Size(480, 28)
    $script:statusTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11, [System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($script:statusTitle)

    $script:statusDetail = New-Object System.Windows.Forms.Label
    $script:statusDetail.Text = "The verified installer is ready. The previous version will be backed up before installation."
    $script:statusDetail.Location = New-Object System.Drawing.Point(30, 112)
    $script:statusDetail.Size = New-Object System.Drawing.Size(480, 44)
    $script:statusDetail.ForeColor = [System.Drawing.Color]::FromArgb(170, 190, 180)
    $script:statusDetail.AutoEllipsis = $true
    $form.Controls.Add($script:statusDetail)

    $script:progress = New-Object System.Windows.Forms.ProgressBar
    $script:progress.Location = New-Object System.Drawing.Point(30, 174)
    $script:progress.Size = New-Object System.Drawing.Size(480, 13)
    $script:progress.Style = [System.Windows.Forms.ProgressBarStyle]::Marquee
    $script:progress.MarqueeAnimationSpeed = 22
    $form.Controls.Add($script:progress)

    $versionLabel = New-Object System.Windows.Forms.Label
    $versionLabel.Text = "NEW VERSION  $ExpectedVersion"
    $versionLabel.Location = New-Object System.Drawing.Point(30, 202)
    $versionLabel.Size = New-Object System.Drawing.Size(240, 22)
    $versionLabel.ForeColor = [System.Drawing.Color]::FromArgb(130, 150, 140)
    $form.Controls.Add($versionLabel)

    $script:launchButton = New-Object System.Windows.Forms.Button
    $script:launchButton.Text = "INSTALLING..."
    $script:launchButton.Location = New-Object System.Drawing.Point(350, 230)
    $script:launchButton.Size = New-Object System.Drawing.Size(160, 38)
    $script:launchButton.Enabled = $false
    $script:launchButton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $script:launchButton.FlatAppearance.BorderSize = 0
    $script:launchButton.BackColor = [System.Drawing.Color]::FromArgb(37, 190, 105)
    $script:launchButton.ForeColor = [System.Drawing.Color]::FromArgb(4, 16, 10)
    $script:launchButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9, [System.Drawing.FontStyle]::Bold)
    $script:launchButton.add_Click({
        if ($script:mode -in @("ready", "launch-failed")) { Launch-UpdatedOri }
        elseif ($script:mode -eq "done") { $form.Close() }
    })
    $form.Controls.Add($script:launchButton)
    $form.add_FormClosing({
        if ($script:mode -in @("installing", "launching")) {
            $_.Cancel = $true
        }
    })
    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()

    if ($ExpectedVersion -notmatch '^[0-9]+\.[0-9]+\.[0-9]+$') { throw "Expected version is not valid SemVer." }
    if ([System.IO.Path]::GetFileName($InstallerPath) -ne "ORI-Setup-$ExpectedVersion.exe") { throw "Installer filename does not match the target version." }
    if (!(Test-Path -LiteralPath $InstallHelperPath -PathType Leaf)) { throw "The bundled installer helper is missing: $InstallHelperPath" }
    if (!(Test-Path -LiteralPath $InstallerPath -PathType Leaf)) { throw "The downloaded installer was not found." }
    if (![string]::IsNullOrWhiteSpace($ExpectedSha256)) {
        $actualHash = (Get-FileHash -LiteralPath $InstallerPath -Algorithm SHA256).Hash
        if (![string]::Equals($actualHash, $ExpectedSha256, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Installer SHA-256 verification failed in the Update Assistant."
        }
    }

    Set-AssistantStatus "Preparing your update" "Launching the protected Windows installer workflow." 10
    $powerShell = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $backendArguments = @(
        "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
        "-File", (Quote-NativeArgument $InstallHelperPath),
        "-AppPid", $AppPid.ToString(),
        "-InstallerPath", (Quote-NativeArgument $InstallerPath),
        "-InstallDir", (Quote-NativeArgument $InstallDir),
        "-ExpectedVersion", $ExpectedVersion,
        "-ExpectedSha256", $ExpectedSha256,
        "-LogPath", (Quote-NativeArgument $BackendLogPath),
        "-RollbackDir", (Quote-NativeArgument $RollbackDir),
        "-NoDialog", "-NoLaunch"
    )
    $argumentLine = $backendArguments -join " "
    if (Test-Path -LiteralPath $BackendLogPath) { Remove-Item -LiteralPath $BackendLogPath -Force }
    $script:backendProcess = Start-Process -FilePath $powerShell -ArgumentList $argumentLine -WindowStyle Hidden -PassThru
    while (!$script:backendProcess.HasExited) {
        [System.Windows.Forms.Application]::DoEvents()
        Read-BackendProgress
        Start-Sleep -Milliseconds 120
        $script:backendProcess.Refresh()
    }
    Read-BackendProgress
    if ($script:backendProcess.ExitCode -ne 0) {
        $tail = ""
        try { $tail = (Get-Content -LiteralPath $BackendLogPath -Tail 8 -ErrorAction Stop) -join " " } catch { }
        throw "The installer could not complete (exit code $($script:backendProcess.ExitCode)). $tail"
    }
    if (!(Test-Path -LiteralPath $installExe -PathType Leaf)) { throw "Setup finished but ORI.exe is missing." }
    Set-AssistantStatus "Update installed successfully" "ORI $ExpectedVersion is installed and verified. Click Launch ORI when you are ready." 100
    $script:mode = "ready"
    $script:launchButton.Text = "LAUNCH ORI"
    $script:launchButton.Enabled = $true

    while ($form.Visible) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 80
    }
}
catch {
    $failure = [string]$_.Exception.Message
    Write-Output "UPDATE ASSISTANT FAILED: $failure"
    if ($script:statusTitle) {
        Set-AssistantStatus "Update could not be completed" "$failure Check the update log for details." 100
        $script:mode = "failed"
        if ($script:launchButton) {
            $script:launchButton.Text = "CLOSE"
            $script:launchButton.Enabled = $true
            $script:launchButton.add_Click({ $form.Close() })
        }
        if ($form -and $form.Visible) {
            while ($form.Visible) {
                [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 80
            }
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show(
            "ORI $ExpectedVersion update could not be completed.`r`n`r`n$failure`r`n`r`nLog: $LogPath",
            "ORI Update Assistant", "OK", "Warning"
        ) | Out-Null
    }
    exit 1
}
finally {
    if ($script:transcriptStarted) { Stop-Transcript | Out-Null }
}
