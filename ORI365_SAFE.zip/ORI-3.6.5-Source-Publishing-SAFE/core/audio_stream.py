"""Small, testable helpers for buffering Gemini Live PCM before speaker writes."""
from __future__ import annotations

import asyncio


async def collect_audio_batch(
    queue: asyncio.Queue,
    first_chunk: bytes,
    *,
    target_bytes: int = 9600,
    max_wait_seconds: float = 0.16,
) -> bytes:
    """Collect up to about 200 ms of mono 24 kHz int16 audio.

    The short bounded wait gives the network stream a chance to deliver adjacent
    50 ms slices together. It smooths small delivery jitter without allowing an
    indefinite wait or adding a full sentence of latency.
    """
    target = max(1, int(target_bytes))
    batch = bytearray(first_chunk or b"")
    if len(batch) >= target or max_wait_seconds <= 0:
        return bytes(batch)

    loop = asyncio.get_running_loop()
    deadline = loop.time() + max(0.0, float(max_wait_seconds))
    while len(batch) < target:
        remaining = deadline - loop.time()
        if remaining <= 0:
            break
        try:
            chunk = await asyncio.wait_for(queue.get(), timeout=remaining)
        except asyncio.TimeoutError:
            break
        if chunk:
            batch.extend(chunk)
    return bytes(batch)


def enqueue_latest(queue: asyncio.Queue, item) -> bool:
    """Insert without blocking, dropping the oldest item when a bounded queue is full.

    Returns True when an old item had to be discarded. Keeping the newest audio
    is preferable to playing seconds-old speech after an output-device stall.
    """
    dropped = False
    try:
        queue.put_nowait(item)
        return dropped
    except asyncio.QueueFull:
        pass

    try:
        queue.get_nowait()
        dropped = True
    except asyncio.QueueEmpty:
        pass

    try:
        queue.put_nowait(item)
    except asyncio.QueueFull:
        # Another producer filled the only free slot between get and put.
        return True
    return dropped


def trim_queue_to(queue: asyncio.Queue, keep_items: int) -> int:
    """Discard oldest queued items until at most ``keep_items`` remain."""
    target = max(0, int(keep_items))
    removed = 0
    while queue.qsize() > target:
        try:
            queue.get_nowait()
            removed += 1
        except asyncio.QueueEmpty:
            break
    return removed


async def enqueue_audio_bytes(
    queue: asyncio.Queue,
    audio_bytes: bytes,
    *,
    chunk_bytes: int = 2400,
    is_current=None,
    retry_interval: float = 0.05,
) -> bool:
    """Enqueue speech PCM in order without silently dropping spoken words.

    The queue is bounded to keep memory predictable. When it fills, the producer
    applies backpressure until playback makes room. ``is_current`` lets an
    interruption invalidate a response while the producer is waiting for room.
    Returns False when the response became stale.
    """
    data = bytes(audio_bytes or b"")
    size = max(1, int(chunk_bytes))
    wait = max(0.01, float(retry_interval))
    for offset in range(0, len(data), size):
        chunk = data[offset:offset + size]
        while True:
            if is_current is not None and not is_current():
                return False
            try:
                queue.put_nowait(chunk)
                break
            except asyncio.QueueFull:
                try:
                    await asyncio.wait_for(queue.put(chunk), timeout=wait)
                except asyncio.TimeoutError:
                    # Re-check the generation token before retrying. An
                    # interruption should never leave old speech waiting to play.
                    continue
                break
        if is_current is not None and not is_current():
            # A generation change can race with a just-completed put. Clear the
            # remaining stale tail as this function is the sole response producer.
            while True:
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
            return False
    return True


def extract_audio_parts(server_content) -> list[bytes]:
    """Return only audio inline-data parts from one Gemini Live server event.

    Read the model-turn parts directly instead of the convenience ``message.data``
    accessor, which concatenates every inline-data part regardless of media type.
    Each audio part is returned exactly once and in provider order.
    """
    model_turn = getattr(server_content, "model_turn", None)
    parts = getattr(model_turn, "parts", None) or ()
    audio: list[bytes] = []
    for part in parts:
        inline = getattr(part, "inline_data", None)
        if inline is None:
            continue
        mime_type = str(getattr(inline, "mime_type", "") or "").lower()
        if mime_type and not mime_type.startswith("audio/"):
            continue
        payload = getattr(inline, "data", None)
        if isinstance(payload, memoryview):
            payload = payload.tobytes()
        elif isinstance(payload, bytearray):
            payload = bytes(payload)
        if isinstance(payload, bytes) and payload:
            audio.append(payload)
    return audio


def append_transcript_fragment(buffer: list[str], fragment: str) -> bool:
    """Merge repeated/cumulative transcription fragments without duplicating words.

    Live transcription events can repeat a previous tail or send a longer
    cumulative prefix. This merge handles both while preserving genuinely new
    text that overlaps the end of the previous fragment.
    """
    incoming = " ".join(str(fragment or "").split()).strip()
    if not incoming:
        return False
    if not buffer:
        buffer.append(incoming)
        return True

    current = " ".join(" ".join(str(item or "").split()) for item in buffer).strip()
    norm = lambda value: [w.casefold().strip(".,!?;:\"'()[]{}") for w in value.split()]
    old_words = norm(current)
    new_words = norm(incoming)
    if not new_words:
        return False

    if old_words == new_words or (len(new_words) <= len(old_words) and
                                  old_words[-len(new_words):] == new_words):
        return False

    # A longer event that begins with the entire current transcript is a
    # cumulative update, not a second sentence.
    if len(new_words) > len(old_words) and new_words[:len(old_words)] == old_words:
        buffer[:] = [incoming]
        return True

    # Remove the largest suffix/prefix overlap (up to 20 words) before append.
    overlap = 0
    for count in range(min(len(old_words), len(new_words), 20), 0, -1):
        if old_words[-count:] == new_words[:count]:
            overlap = count
            break
    remainder = incoming.split()[overlap:]
    if not remainder:
        return False
    buffer.append(" ".join(remainder))
    return True
