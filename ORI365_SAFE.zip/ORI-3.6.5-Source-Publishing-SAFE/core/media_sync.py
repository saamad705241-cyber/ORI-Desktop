"""Pure playback-sync policy shared by the HUD and its regression tests.

YouTube serves picture and sound as two separate streams, so ORI plays them in
two QMediaPlayer objects. Two independent players always drift apart a little
(separate clocks, separate network buffering), and after some minutes the drift
becomes noticeable.

THE SOUND IS THE MASTER CLOCK. Listeners hear every discontinuity in audio
(a rate change re-initialises the resampler, a seek flushes the decoder), but a
picture that runs 4 % fast for a second or two, or pauses for a moment, is
invisible. So all corrections are applied to the *video* player; the audio
player is never touched after it starts.
"""
from __future__ import annotations

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Legacy helper, kept for API compatibility. The HUD no longer uses it because
# it corrected the *audio* player, which is exactly what produced the
# stuttering soundtrack after several minutes of playback.
# ---------------------------------------------------------------------------
def audio_sync_action(
    audio_minus_video_ms: float,
    *,
    soft_limit_ms: float = 150.0,
    hard_limit_ms: float = 900.0,
) -> tuple[float, bool]:
    """Return (audio playback rate, should_hard_seek). Deprecated."""
    drift = float(audio_minus_video_ms)
    magnitude = abs(drift)
    if magnitude <= max(0.0, soft_limit_ms):
        return 1.0, False
    if magnitude >= max(soft_limit_ms + 1.0, hard_limit_ms):
        return 1.0, True
    return (0.995 if drift > 0 else 1.005), False


def video_follow_action(
    video_minus_audio_ms: float,
    current_rate: float = 1.0,
    *,
    enter_ms: float = 120.0,
    leave_ms: float = 40.0,
    seek_ms: float = 1500.0,
    catchup: float = 0.04,
) -> tuple[float, bool]:
    """Return (video playback rate, should_seek_video) to follow the audio.

    * Inside ``enter_ms`` nothing is corrected at all.
    * Once a correction has started it continues until the drift is below
      ``leave_ms`` (hysteresis), so the rate cannot flip back and forth every
      time the measured drift wobbles around a single threshold.
    * Beyond ``seek_ms`` a one-off seek of the *video* is requested.
    """
    drift = float(video_minus_audio_ms)
    magnitude = abs(drift)
    if magnitude >= max(enter_ms + 1.0, seek_ms):
        return 1.0, True
    correcting = abs(float(current_rate) - 1.0) > 1e-6
    threshold = leave_ms if correcting else enter_ms
    if magnitude <= max(0.0, threshold):
        return 1.0, False
    # Video ahead of the sound must slow down; video behind must speed up.
    return (1.0 - catchup) if drift > 0 else (1.0 + catchup), False


@dataclass(frozen=True)
class SyncDecision:
    """What the UI should do to the VIDEO player this tick (audio is never touched)."""

    video_rate: float | None = None      # None = leave the playback rate alone
    seek_video_to_ms: int | None = None  # None = do not seek
    pause_video: bool = False
    resume_video: bool = False


class SplitStreamSync:
    """Stateful audio-master controller for a split picture/sound pair."""

    def __init__(
        self,
        *,
        seek_cooldown_s: float = 8.0,
        max_hold_s: float = 20.0,
        hold_retry_after_s: float = 30.0,
    ) -> None:
        self.seek_cooldown_s = seek_cooldown_s
        self.max_hold_s = max_hold_s
        self.hold_retry_after_s = hold_retry_after_s
        self.rate = 1.0
        self.holding = False
        self._held_since = 0.0
        self._hold_blocked_until = 0.0
        self._last_seek = float("-inf")

    def decide(
        self,
        *,
        audio_ms: float,
        video_ms: float,
        audio_waiting: bool,
        video_waiting: bool,
        now: float,
    ) -> SyncDecision:
        """Decide corrections for one timer tick.

        ``audio_waiting`` / ``video_waiting`` are True while the player is
        loading, stalled or buffering; its reported position means nothing
        then.
        """
        # 1. Sound ran out of data: hold the picture instead of letting it run
        #    ahead, then release it when the sound is flowing again. The
        #    soundtrack itself is left strictly alone.
        if self.holding:
            if not audio_waiting:
                self.holding = False
                return SyncDecision(resume_video=True)
            if now - self._held_since >= self.max_hold_s:
                self.holding = False
                self._hold_blocked_until = now + self.hold_retry_after_s
                return SyncDecision(resume_video=True)
            return SyncDecision()
        if audio_waiting:
            if now >= self._hold_blocked_until:
                self.holding = True
                self._held_since = now
                return SyncDecision(pause_video=True)
            return SyncDecision()

        # 2. Picture is buffering: its position is stale, so measuring drift
        #    now would trigger a pointless correction.
        if video_waiting:
            return SyncDecision()

        drift = float(video_ms) - float(audio_ms)
        rate, want_seek = video_follow_action(drift, self.rate)

        if want_seek:
            if now - self._last_seek >= self.seek_cooldown_s:
                self._last_seek = now
                self.rate = 1.0
                return SyncDecision(
                    video_rate=1.0,
                    seek_video_to_ms=max(0, int(audio_ms)),
                )
            # Seek is cooling down: close the gap with the fastest allowed
            # catch-up rate rather than leave it uncorrected.
            rate = 0.96 if drift > 0 else 1.04

        if abs(rate - self.rate) > 1e-6:
            self.rate = rate
            return SyncDecision(video_rate=rate)
        return SyncDecision()
