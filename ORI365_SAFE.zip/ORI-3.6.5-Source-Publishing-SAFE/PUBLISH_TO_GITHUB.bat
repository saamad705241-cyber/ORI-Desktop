@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ===============================================
echo ORI 3.6.5 - Safe GitHub publish helper
echo ===============================================

where git >nul 2>&1 || (echo ERROR: Git is not installed. Install Git for Windows first.& pause & exit /b 1)
if not exist ".git" (echo ERROR: Extract these source files into your existing ORI-Desktop Git repository root, not a new folder.& pause & exit /b 1)

for /f "delims=" %%B in ('git branch --show-current') do set "BRANCH=%%B"
if /i not "%BRANCH%"=="main" (echo ERROR: Current branch is "%BRANCH%". Switch to main before publishing.& pause & exit /b 1)

for /f "delims=" %%R in ('git remote get-url origin 2^>nul') do set "REMOTE=%%R"
echo %REMOTE% | findstr /i /c:"github.com/saamad705241-cyber/ORI-Desktop" /c:"github.com:saamad705241-cyber/ORI-Desktop" >nul
if errorlevel 1 (echo ERROR: origin is not the expected ORI-Desktop GitHub repository.& echo Current origin: %REMOTE%& pause & exit /b 1)

findstr /r /c:"^APP_VERSION = .3\.6\.5." ori_metadata.py >nul
if errorlevel 1 (echo ERROR: ori_metadata.py is not set to version 3.6.5.& pause & exit /b 1)

for /f %%S in ('git diff --cached --name-only') do (echo ERROR: You already have staged changes. Commit or unstage them first.& pause & exit /b 1)

echo.
echo Current changes:
git status --short
echo.
echo This will commit the corrected 3.6.5 source and push it to origin/main.
echo GitHub Actions will run tests, build the Windows Setup and publish v3.6.5 only if all release checks pass.
set /p "CONFIRM=Continue? Type YES: "
if /i not "%CONFIRM%"=="YES" (echo Cancelled. No files were pushed.& pause & exit /b 0)

git add -A
if errorlevel 1 (echo ERROR: git add failed.& pause & exit /b 1)

echo.
echo Staged summary:
git diff --cached --stat
set /p "CONFIRM2=Commit and push these changes? Type YES: "
if /i not "%CONFIRM2%"=="YES" (git reset >nul & echo Cancelled. The staged changes were unstaged; no push was made.& pause & exit /b 0)

git commit -m "release: ORI 3.6.5 from corrected Update Assistant source"
if errorlevel 1 (echo ERROR: Commit failed. Nothing was pushed.& pause & exit /b 1)

git push origin main
if errorlevel 1 (echo ERROR: Push failed. Check GitHub authentication and retry git push origin main.& pause & exit /b 1)

echo.
echo Source pushed successfully. Now monitor GitHub Actions and wait for the v3.6.5 release to appear.
echo Do not install a build until the GitHub release workflow has completed successfully.
pause
