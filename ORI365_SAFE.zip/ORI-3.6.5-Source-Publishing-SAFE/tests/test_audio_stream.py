import asyncio

from core.audio_stream import collect_audio_batch


def test_collect_audio_batch_waits_for_adjacent_pcm_slices():
    async def run():
        queue = asyncio.Queue()
        queue.put_nowait(b"BBBB")
        batch = await collect_audio_batch(
            queue, b"AAAA", target_bytes=8, max_wait_seconds=0.05
        )
        return batch

    assert asyncio.run(run()) == b"AAAABBBB"


def test_collect_audio_batch_returns_partial_audio_after_bounded_wait():
    async def run():
        queue = asyncio.Queue()
        return await collect_audio_batch(
            queue, b"first", target_bytes=20, max_wait_seconds=0.01
        )

    assert asyncio.run(run()) == b"first"


def test_collect_audio_batch_does_not_wait_when_response_is_complete():
    async def run():
        queue = asyncio.Queue()
        return await collect_audio_batch(
            queue, b"last", target_bytes=32, max_wait_seconds=0
        )

    assert asyncio.run(run()) == b"last"


def test_enqueue_latest_drops_oldest_when_output_queue_is_full():
    from core.audio_stream import enqueue_latest

    queue = asyncio.Queue(maxsize=2)
    queue.put_nowait(b"old-1")
    queue.put_nowait(b"old-2")

    assert enqueue_latest(queue, b"new") is True
    assert queue.get_nowait() == b"old-2"
    assert queue.get_nowait() == b"new"


def test_enqueue_latest_does_not_drop_when_queue_has_capacity():
    from core.audio_stream import enqueue_latest

    queue = asyncio.Queue(maxsize=2)
    assert enqueue_latest(queue, b"first") is False
    assert queue.get_nowait() == b"first"


def test_trim_queue_to_discards_oldest_audio_backlog():
    from core.audio_stream import trim_queue_to

    queue = asyncio.Queue(maxsize=100)
    for i in range(40):
        queue.put_nowait(i)
    assert trim_queue_to(queue, 12) == 28
    assert queue.qsize() == 12
    assert queue.get_nowait() == 28
