from core.hardware_sensors import parse_lhm_cpu_temperature, parse_lhm_gpu_temperature, get_system_temperature
from actions import system_monitor


def test_lhm_json_prefers_cpu_package_and_ignores_gpu_temperatures():
    payload = {
        "Text": "Computer",
        "Children": [
            {
                "Text": "AMD Ryzen 7 170 with Radeon Graphics",
                "Type": "Hardware",
                "Children": [
                    {
                        "Text": "Temperatures",
                        "Children": [
                            {"Text": "CPU CCD #0 (Tdie)", "Type": "Temperature", "Value": "54.0 °C", "RawValue": 54.0},
                            {"Text": "CPU Package", "Type": "Temperature", "Value": "57.0 °C", "RawValue": 57.0},
                        ],
                    }
                ],
            },
            {
                "Text": "NVIDIA GeForce RTX 4050 Laptop GPU",
                "Type": "Hardware",
                "Children": [
                    {"Text": "GPU Core", "Type": "Temperature", "Value": "45.0 °C", "RawValue": 45.0}
                ],
            },
        ],
    }

    reading = parse_lhm_cpu_temperature(payload)

    assert reading == {
        "temperature_c": 57.0,
        "sensor": "CPU Package",
        "provider": "LibreHardwareMonitor HTTP",
    }


def test_lhm_json_accepts_cpu_sensor_value_without_raw_value():
    payload = {
        "Text": "AMD Ryzen 7 170",
        "Children": [
            {"Text": "Tctl/Tdie", "Type": "Temperature", "Value": "51.5 °C"}
        ],
    }

    reading = parse_lhm_cpu_temperature(payload)

    assert reading["temperature_c"] == 51.5
    assert reading["sensor"] == "Tctl/Tdie"


def test_lhm_json_does_not_guess_from_unrelated_or_gpu_sensors():
    payload = {
        "Text": "Computer",
        "Children": [
            {"Text": "NVIDIA GeForce RTX 4050", "Children": [
                {"Text": "GPU Core", "Type": "Temperature", "Value": "44 °C"}
            ]},
            {"Text": "Motherboard", "Children": [
                {"Text": "System", "Type": "Temperature", "Value": "38 °C"}
            ]},
        ],
    }

    assert parse_lhm_cpu_temperature(payload) is None


def test_lhm_json_rejects_out_of_range_sensor_values():
    payload = {
        "Text": "Intel Core i7 CPU",
        "Children": [
            {"Text": "CPU Package", "Type": "Temperature", "RawValue": 180.0}
        ],
    }

    assert parse_lhm_cpu_temperature(payload) is None



def test_lhm_json_supports_decimal_comma_sensor_values():
    payload = {
        "Text": "AMD Ryzen 7 170",
        "Children": [
            {"Text": "Core (Tctl/Tdie)", "Type": "Temperature", "Value": "46,9 °C"}
        ],
    }

    reading = parse_lhm_cpu_temperature(payload)

    assert reading["temperature_c"] == 46.9



def test_voice_system_status_uses_the_same_cpu_sensor_as_the_hud(monkeypatch):
    monkeypatch.setattr(
        system_monitor,
        "get_system_temperature",
        lambda: {
            "temperature_c": 58.4,
            "sensor": "CPU Package",
            "provider": "LibreHardwareMonitor HTTP",
        },
    )

    assert system_monitor._get_cpu_temp() == 58.4


def test_voice_system_status_reports_unavailable_instead_of_guessing(monkeypatch):
    monkeypatch.setattr(system_monitor, "get_system_temperature", lambda: None)
    assert system_monitor._get_cpu_temp() == -1.0


def test_voice_system_status_rejects_invalid_shared_sensor_data(monkeypatch):
    monkeypatch.setattr(
        system_monitor, "get_system_temperature",
        lambda: {"temperature_c": 180.0, "sensor": "unknown"},
    )
    assert system_monitor._get_cpu_temp() == -1.0



def test_lhm_json_reads_gpu_temperature_when_gpu_is_the_available_sensor():
    payload = {
        "Text": "Computer",
        "Children": [{
            "Text": "NVIDIA GeForce GT 1030",
            "Type": "Hardware",
            "Children": [{
                "Text": "Temperatures",
                "Children": [
                    {"Text": "GPU Core", "Type": "Temperature", "Value": "49.0 °C", "RawValue": 49.0}
                ],
            }],
        }],
    }
    reading = parse_lhm_gpu_temperature(payload)
    assert reading == {
        "temperature_c": 49.0,
        "sensor": "GPU Core",
        "provider": "LibreHardwareMonitor GPU",
    }


def test_system_temperature_prefers_cpu_then_uses_gpu_fallback(monkeypatch):
    from core import hardware_sensors
    payload = {
        "Text": "Computer",
        "Children": [{
            "Text": "NVIDIA GeForce GT 1030",
            "Children": [{"Text": "GPU Core", "Type": "Temperature", "Value": "47 °C"}],
        }],
    }
    monkeypatch.setattr(hardware_sensors, "_read_lhm_payload", lambda: payload)
    monkeypatch.setattr(hardware_sensors, "_read_legacy_wmi", lambda: None)
    monkeypatch.setattr(hardware_sensors, "_read_psutil", lambda: None)
    monkeypatch.setattr(hardware_sensors, "_read_nvidia_nvml_gpu_temperature", lambda: None)
    reading = get_system_temperature()
    assert reading["temperature_c"] == 47.0
    assert reading["provider"] == "LibreHardwareMonitor GPU"
