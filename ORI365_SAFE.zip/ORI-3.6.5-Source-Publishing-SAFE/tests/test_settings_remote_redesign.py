import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SettingsRemoteRedesignTests(unittest.TestCase):
    def test_settings_builder_uses_category_stack_with_scrollable_content(self):
        source = (ROOT / "ui.py").read_text(encoding="utf-8")
        start = source.index("    def _build_settings_page(self) -> QWidget:")
        end = source.index("    def _select_settings_category(", start)
        section = source[start:end]
        self.assertIn("QStackedWidget", section)
        self.assertIn("QScrollArea", section)
        self.assertIn("setWidgetResizable(True)", section)
        self.assertIn("ScrollBarPolicy.ScrollBarAsNeeded", section)
        self.assertIn("PHONE REMOTE", section)
        self.assertIn('"settings-phone.svg"', section)
        self.assertIn('"settings-about.svg"', section)
        self.assertIn('("UPDATES", "settings-system.svg")', section)
        self.assertIn('("TERMS", "settings-about.svg")', section)
        self.assertIn('self._settings_instagram_btn = QPushButton("  INSTAGRAM")', section)
        self.assertIn('QDesktopServices.openUrl(QUrl(_SETTINGS_INSTAGRAM_URL))', section)
        self.assertNotIn("ORI · ORIGINAL LOGO", section)
        self.assertNotIn("SHOW ABOUT DETAILS", section)
        self.assertNotIn('button("TERMS & CONDITIONS")', section)
        self.assertNotIn('button("UNINSTALL ORI")', section)
        self.assertNotIn("schedule_uninstall", section)

    def test_about_updates_and_terms_are_separate_settings_pages(self):
        source = (ROOT / "ui.py").read_text(encoding="utf-8")
        about = source.split("        # ABOUT ", 1)[1].split("        # UPDATES", 1)[0]
        updates = source.split("        # UPDATES", 1)[1].split("        # TERMS", 1)[0]
        terms = source.split("        # TERMS", 1)[1].split("        self._settings_page_status", 1)[0]
        self.assertIn('panel(l5, "ABOUT ORI"', about)
        self.assertIn('("Version", f"{_ORI_VERSION}")', about)
        self.assertNotIn("INSTAGRAM", about)
        self.assertNotIn("CHECK FOR UPDATES", about)
        self.assertNotIn('panel(l5, "TERMS', about)
        self.assertNotIn("terms_button", about)
        self.assertIn('button("CHECK FOR UPDATES", True)', updates)
        self.assertIn('panel(l7, "TERMS & CONDITIONS"', terms)
        self.assertIn("terms_body.setReadOnly(True)", terms)

    def test_update_flow_uses_one_sequential_button(self):
        source = (ROOT / "ui.py").read_text(encoding="utf-8")
        start = source.index("        # UPDATES")
        end = source.index("        # TERMS", start)
        section = source[start:end]
        self.assertIn('button("CHECK FOR UPDATES", True)', section)
        self.assertIn("self._update_action_btn.clicked.connect(self._handle_update_action)", section)
        self.assertNotIn('button("DOWNLOAD UPDATE")', section)
        self.assertNotIn('button("INSTALL UPDATE")', section)
        self.assertNotIn('button("UNINSTALL ORI")', section)

        handlers = source.split("    def _handle_update_action(", 1)[1].split(
            "    def _refresh_settings_status(", 1
        )[0]
        self.assertIn('stage == "download"', handlers)
        self.assertIn('stage == "install"', handlers)
        self.assertIn('"DOWNLOAD UPDATE"', handlers)
        self.assertIn('"OPEN UPDATE ASSISTANT"', handlers)
        self.assertIn("schedule_windows_update", handlers)
        self.assertNotIn("schedule_uninstall", handlers)

    def test_network_chip_shows_download_only(self):
        source = (ROOT / "ui.py").read_text(encoding="utf-8")
        start = source.index("        # NET", source.index("    def _update_metrics(self):"))
        end = source.index("        # GPU", start)
        block = source[start:end]
        self.assertIn('MetricChip("NET", C.PRI, 112)', source)
        self.assertIn('f"↓ {_fmt_rate(rx_bps, compact=True)}"', block)
        self.assertIn("Download:", block)
        self.assertNotIn("Upload:", block)
        self.assertNotIn("tx_mbps", block)

    def test_original_logo_is_used_in_application_and_branding(self):
        source = (ROOT / "ui.py").read_text(encoding="utf-8")
        self.assertIn('CONFIG_DIR / "ori.ico"', source)
        self.assertIn("self._app.setWindowIcon(_app_icon)", source)
        self.assertIn("self._win.setWindowIcon(_app_icon)", source)
        packaged_icons = (
            "settings-profile.svg", "settings-audio.svg", "settings-appearance.svg",
            "settings-system.svg", "settings-phone.svg", "settings-about.svg",
        )
        for icon in packaged_icons:
            self.assertTrue((ROOT / "config" / icon).is_file())
            self.assertIn(f'config\\{icon};config', (ROOT / "build_windows_exe.bat").read_text(encoding="utf-8"))
            self.assertIn(f'config\\{icon};config', (ROOT / "scripts" / "build_release.ps1").read_text(encoding="utf-8"))

    def test_instagram_icon_uses_ori_green_not_social_gradient(self):
        icon = (ROOT / "config" / "instagram.svg").read_text(encoding="utf-8")
        self.assertIn("#43ff91", icon)
        self.assertNotIn("#D62976", icon)

    def test_dynamic_settings_labels_replace_underscores(self):
        source = (ROOT / "ui.py").read_text(encoding="utf-8")
        self.assertIn('replace("_", " ").replace("-", " ")', source)

    def test_onboarding_marks_google_and_email_auth_as_coming_soon(self):
        source = (ROOT / "ui.py").read_text(encoding="utf-8")
        self.assertIn("CONTINUE WITH GOOGLE", source)
        self.assertIn("SEND EMAIL CODE", source)
        self.assertIn("Email OTP sign-in is coming soon", source)
        self.assertIn("CONTINUE AS A GUEST", source)

    def test_remote_dashboard_exposes_authentication_and_dynamic_port(self):
        source = (ROOT / "dashboard" / "server.py").read_text(encoding="utf-8")
        self.assertIn("_find_available_port", source)
        self.assertIn("/api/desktop/screenshot", source)
        self.assertIn("if not _auth(req)", source)

    def test_mobile_dashboard_exposes_explicit_pc_screen_action(self):
        source = (ROOT / "dashboard" / "static" / "app.html").read_text(encoding="utf-8")
        self.assertIn("PC SCREEN", source)
        self.assertIn("captureDesktopScreen", source)


if __name__ == "__main__":
    unittest.main()
