from core.media_sync import (
    SplitStreamSync,
    audio_sync_action,
    video_follow_action,
)


# -- legacy helper stays stable ------------------------------------------------
def test_legacy_audio_helper_contract_is_unchanged():
    assert audio_sync_action(90) == (1.0, False)
    assert audio_sync_action(450) == (0.995, False)
    assert audio_sync_action(-1200) == (1.0, True)


# -- video follows the audio ---------------------------------------------------
def test_small_drift_is_left_completely_alone():
    assert video_follow_action(100, 1.0) == (1.0, False)
    assert video_follow_action(-119, 1.0) == (1.0, False)


def test_video_ahead_slows_and_video_behind_speeds_up():
    assert video_follow_action(300, 1.0) == (0.96, False)
    assert video_follow_action(-300, 1.0) == (1.04, False)


def test_hysteresis_prevents_rate_flapping_around_the_threshold():
    # Not yet correcting: 100 ms is inside the dead zone.
    assert video_follow_action(100, 1.0) == (1.0, False)
    # Already correcting: keep going until the drift is really small...
    assert video_follow_action(100, 0.96) == (0.96, False)
    assert video_follow_action(60, 0.96) == (0.96, False)
    # ...and only then return to normal speed.
    assert video_follow_action(30, 0.96) == (1.0, False)


def test_large_drift_requests_one_video_seek():
    assert video_follow_action(2000, 1.0) == (1.0, True)
    assert video_follow_action(-2000, 1.0) == (1.0, True)


# -- controller: audio is never the thing being corrected -----------------------
def _tick(sync, now, audio, video, a_wait=False, v_wait=False):
    return sync.decide(
        audio_ms=audio, video_ms=video,
        audio_waiting=a_wait, video_waiting=v_wait, now=now,
    )


def test_controller_never_returns_an_audio_action():
    sync = SplitStreamSync()
    decision = _tick(sync, 0.0, 10_000, 10_400)
    assert not hasattr(decision, "audio_rate")
    assert not hasattr(decision, "seek_audio_to_ms")
    assert decision.video_rate == 0.96


def test_gradual_drift_over_minutes_is_corrected_on_the_video_only():
    sync = SplitStreamSync()
    changes = 0
    seeks = 0
    audio = 0.0
    video = 0.0
    worst = 0.0
    # 10 minutes, one tick per second. The video clock runs 0.5 % slow; the
    # controller's rate correction feeds back into that clock.
    for second in range(600):
        audio += 1000.0
        video += 1000.0 * sync.rate * 0.995
        decision = _tick(sync, float(second), audio, video)
        if decision.seek_video_to_ms is not None:
            seeks += 1
            video = float(decision.seek_video_to_ms)
        if decision.video_rate is not None:
            changes += 1
        worst = max(worst, abs(video - audio))
    assert seeks == 0                 # gentle rate nudges are enough
    assert worst < 200.0              # lip-sync always stays tight
    assert changes <= 70              # no per-second flapping (was every tick)


def test_seek_is_rate_limited_and_targets_the_audio_position():
    sync = SplitStreamSync()
    first = _tick(sync, 0.0, 50_000, 55_000)
    assert first.seek_video_to_ms == 50_000
    assert first.video_rate == 1.0
    again = _tick(sync, 2.0, 50_000, 55_000)   # still far off, cooldown active
    assert again.seek_video_to_ms is None
    assert again.video_rate == 0.96
    later = _tick(sync, 9.0, 60_000, 65_000)
    assert later.seek_video_to_ms == 60_000


def test_picture_is_held_while_sound_buffers_and_released_afterwards():
    sync = SplitStreamSync()
    assert _tick(sync, 0.0, 5_000, 5_000, a_wait=True).pause_video is True
    assert _tick(sync, 1.0, 5_000, 5_000, a_wait=True) == _tick(sync, 1.5, 5_000, 5_000, a_wait=True)
    released = _tick(sync, 2.0, 5_100, 5_000, a_wait=False)
    assert released.resume_video is True


def test_hold_is_bounded_so_the_picture_cannot_freeze_forever():
    sync = SplitStreamSync(max_hold_s=20.0, hold_retry_after_s=30.0)
    assert _tick(sync, 0.0, 0, 0, a_wait=True).pause_video is True
    assert _tick(sync, 21.0, 0, 0, a_wait=True).resume_video is True
    # Blocked from re-holding for a while, so it cannot flap every tick.
    assert _tick(sync, 22.0, 0, 0, a_wait=True).pause_video is False


def test_no_correction_is_computed_from_a_stale_video_position():
    sync = SplitStreamSync()
    decision = _tick(sync, 0.0, 90_000, 10_000, v_wait=True)
    assert decision.seek_video_to_ms is None
    assert decision.video_rate is None
