from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_inno_setup_is_per_user_with_shortcuts_and_uninstaller():
    source = (ROOT / "installer" / "ORI.iss").read_text(encoding="utf-8")
    assert "PrivilegesRequired=lowest" in source
    assert "DefaultDirName={localappdata}\\Programs\\ORI" in source
    assert 'Name: "{autoprograms}\\ORI"' in source
    assert 'Name: "{autodesktop}\\ORI"' in source
    assert "Uninstallable=yes" in source
    assert "UninstallDisplayName=ORI Personal AI Desktop Assistant" in source
    assert "skipifsilent" in source


def test_installer_does_not_package_live_credentials():
    source = (ROOT / "installer" / "ORI.iss").read_text(encoding="utf-8")
    build = (ROOT / "scripts" / "build_release.ps1").read_text(encoding="utf-8")
    assert 'Excludes: "config\\api_keys.json"' in source
    assert "Copy-Item \"config\\api_keys.example.json\" \"dist\\ORI\\config\\api_keys.json\"" not in build
    assert "config/api_keys.json" not in build


def test_update_helper_runs_setup_and_requires_startup_marker_before_success():
    source = (ROOT / "core" / "install_update.ps1").read_text(encoding="utf-8")
    # ORI gets a short grace period, then lingering ORI.exe processes from the
    # install directory are ended so the update can never stall for minutes.
    assert "Wait-Process -Id $AppPid -Timeout 25" in source
    assert "Stop-Process -Id $proc.Id -Force" in source
    assert "/FORCECLOSEAPPLICATIONS" in source
    assert "/VERYSILENT" in source
    assert "/CLOSEAPPLICATIONS" in source
    assert "ORI_STARTUP_TOKEN" not in source
    assert "--ori-update-token=$token" in source
    assert "UPDATE SUCCESS" in source
    assert "ROLLBACK SUCCESS" in source
    assert "startup" in source
    assert "$ExpectedVersion" in source
    assert "$startup.version" in source
    assert "$startup.executable" in source
    assert "15-second post-start stability check" in source
    assert "[switch]$NoDialog" in source
    assert "if (!$NoDialog)" in source


def test_uninstaller_launcher_preserves_personal_data_folder():
    source = (ROOT / "core" / "uninstall_launcher.ps1").read_text(encoding="utf-8")
    assert "Wait-Process -Id $AppPid" in source
    assert "uninstall wizard" in source.lower()
    assert "LocalAppData\\ORI is not removed" in source


def test_user_data_paths_are_outside_the_install_directory_for_frozen_builds():
    source = (ROOT / "core" / "app_paths.py").read_text(encoding="utf-8")
    assert 'Path(sys.executable).resolve().parent' in source
    assert 'root / APP_NAME' in source
    assert '"config" / "api_keys.json"' in source
    assert '"memory" / "long_term.json"' in source


def test_ci_exercises_a_real_in_place_upgrade_from_published_360():
    workflow = (ROOT / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")
    assert "ORI-Setup-3.6.0.exe" in workflow
    assert "core/install_update.ps1" in workflow
    assert "UPDATE SUCCESS" in workflow
    assert "-ExpectedVersion $version" in workflow
    assert "DisplayVersion" in workflow
    assert "ci-update-preservation.txt" in workflow



def test_update_startup_marker_reports_version_and_executable_identity():
    source = (ROOT / "main.py").read_text(encoding="utf-8")
    assert '"version": APP_VERSION' in source
    assert '"executable": os.path.normcase(os.path.abspath(sys.executable))' in source


def test_update_helper_restarts_current_ori_when_nothing_was_changed():
    source = (ROOT / "core" / "install_update.ps1").read_text(encoding="utf-8")
    assert "No files were changed. The current ORI was started again." in source


def test_application_really_exits_when_handing_off_to_the_helper():
    ui = (ROOT / "ui.py").read_text(encoding="utf-8")
    main = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "def _quit_for_external_helper" in ui
    assert "os._exit(0)" in ui
    # Only the update flow is exposed in-app. Uninstallation is handled by
    # the standard Windows Apps / Installed Apps entry registered by Setup.
    assert ui.count("self._quit_for_external_helper()") == 1
    assert 'button("UNINSTALL ORI")' not in ui
    assert "_arm_exit_watchdog(8.0)" in main
    assert "startup_timer.daemon = True" in main


def test_video_sync_never_adjusts_the_audio_player():
    ui = (ROOT / "ui.py").read_text(encoding="utf-8")
    start = ui.index("def _sync_video_sound")
    end = ui.index("def _sync_video_mute_btn")
    body = ui[start:end]
    assert "self._video_sound.setPlaybackRate" not in body
    assert "self._video_sound.setPosition" not in body
    assert "self._video_player.setPlaybackRate" in body


def test_update_assistant_provides_visible_install_and_launch_flow():
    assistant = (ROOT / "core" / "update_assistant.ps1").read_text(encoding="utf-8")
    backend = (ROOT / "core" / "install_update.ps1").read_text(encoding="utf-8")
    assert "ORI  /  UPDATE ASSISTANT" in assistant
    assert "System.Windows.Forms.ProgressBar" in assistant
    assert "LAUNCH ORI" in assistant
    assert "Application]::DoEvents" in assistant
    assert "--ori-update-token=$token" in assistant
    assert "$startup.version" in assistant
    assert "$startup.executable" in assistant
    assert "15" in assistant
    assert "[switch]$NoLaunch" in backend
    assert "waiting for the user to launch ORI" in backend


def test_update_download_reports_real_progress_to_the_ui():
    updater = (ROOT / "core" / "app_updater.py").read_text(encoding="utf-8")
    ui = (ROOT / "ui.py").read_text(encoding="utf-8")
    assert "progress_callback: Callable[[dict[str, Any]], None]" in updater
    assert '"downloaded_bytes"' in updater
    assert '"total_bytes"' in updater
    assert "_app_update_progress_sig" in ui
    assert "OPEN UPDATE ASSISTANT" in ui
    assert "LAUNCH ORI" in ui
