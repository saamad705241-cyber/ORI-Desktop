from core.live_tool_policy import behavior_for_tool, scheduling_for_tool


def test_safe_lookups_and_app_launches_are_non_blocking():
    for name in ("open_app", "web_search", "current_weather", "youtube_video", "video_player"):
        assert behavior_for_tool(name) == "NON_BLOCKING"
        assert scheduling_for_tool(name) == "WHEN_IDLE"


def test_state_changing_tools_remain_blocking_by_default():
    for name in ("computer_control", "file_controller", "send_message", "windows_update"):
        assert behavior_for_tool(name) == "BLOCKING"
        assert scheduling_for_tool(name) is None


def test_explicit_valid_behavior_overrides_policy():
    assert behavior_for_tool("open_app", "BLOCKING") == "BLOCKING"
    assert behavior_for_tool("computer_control", "NON_BLOCKING") == "NON_BLOCKING"


def test_invalid_behavior_does_not_weaken_safe_default():
    assert behavior_for_tool("computer_control", "SOMETIMES") == "BLOCKING"


def test_function_response_scheduling_is_nested_in_response_payload():
    from core.live_tool_policy import function_response_payload

    assert function_response_payload("opened", "WHEN_IDLE") == {
        "result": "opened", "scheduling": "WHEN_IDLE"
    }
    assert function_response_payload("opened", "bad-value") == {"result": "opened"}


def test_blocking_tools_do_not_receive_async_response_scheduling():
    assert scheduling_for_tool("computer_control", "INTERRUPT", "BLOCKING") is None


def test_async_live_capability_matches_model_fallbacks():
    from core.live_tool_policy import supports_async_live_tools

    assert supports_async_live_tools("gemini-3.8-live") is True
    assert supports_async_live_tools("gemini-2.5-flash-native-audio-preview-12-2025") is True
    assert supports_async_live_tools("gemini-3.1-flash-live-preview") is False
