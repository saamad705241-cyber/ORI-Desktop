import asyncio
from types import SimpleNamespace

from core.audio_stream import (
    append_transcript_fragment,
    enqueue_audio_bytes,
    extract_audio_parts,
)


def test_extract_audio_parts_returns_each_audio_part_once_and_skips_images():
    server_content = SimpleNamespace(
        model_turn=SimpleNamespace(parts=[
            SimpleNamespace(inline_data=SimpleNamespace(
                mime_type="audio/pcm;rate=24000", data=b"first"
            )),
            SimpleNamespace(inline_data=SimpleNamespace(
                mime_type="image/jpeg", data=b"not-audio"
            )),
            SimpleNamespace(inline_data=SimpleNamespace(
                mime_type="audio/pcm;rate=24000", data=bytearray(b"second")
            )),
        ])
    )
    assert extract_audio_parts(server_content) == [b"first", b"second"]


def test_enqueue_audio_bytes_preserves_order_with_bounded_queue_backpressure():
    async def run():
        queue = asyncio.Queue(maxsize=2)
        producer = asyncio.create_task(
            enqueue_audio_bytes(queue, b"abcdefgh", chunk_bytes=2)
        )
        received = bytearray()
        while not producer.done() or not queue.empty():
            try:
                piece = await asyncio.wait_for(queue.get(), timeout=0.25)
            except asyncio.TimeoutError:
                break
            received.extend(piece)
        assert await producer is True
        return bytes(received)

    assert asyncio.run(run()) == b"abcdefgh"


def test_enqueue_audio_bytes_stops_when_interruption_invalidates_response():
    async def run():
        queue = asyncio.Queue(maxsize=1)
        queue.put_nowait(b"old")
        generation = [1]
        producer = asyncio.create_task(
            enqueue_audio_bytes(
                queue,
                b"new-audio",
                chunk_bytes=3,
                is_current=lambda: generation[0] == 1,
                retry_interval=0.01,
            )
        )
        await asyncio.sleep(0.03)
        generation[0] = 2
        # Mimic the interruption handler flushing queued speaker audio.
        while not queue.empty():
            queue.get_nowait()
        result = await asyncio.wait_for(producer, timeout=0.5)
        return result, queue.qsize()

    assert asyncio.run(run()) == (False, 0)


def test_transcript_merge_ignores_exact_repeats():
    pieces = []
    assert append_transcript_fragment(pieces, "Open Google Chrome") is True
    assert append_transcript_fragment(pieces, "Open Google Chrome") is False
    assert " ".join(pieces) == "Open Google Chrome"


def test_transcript_merge_replaces_cumulative_prefix_instead_of_repeating_it():
    pieces = []
    append_transcript_fragment(pieces, "Please open")
    append_transcript_fragment(pieces, "Please open Google Chrome")
    assert " ".join(pieces) == "Please open Google Chrome"


def test_transcript_merge_removes_overlap_between_adjacent_fragments():
    pieces = []
    append_transcript_fragment(pieces, "Please open Google")
    append_transcript_fragment(pieces, "Google Chrome now")
    assert " ".join(pieces) == "Please open Google Chrome now"
