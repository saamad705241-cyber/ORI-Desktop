ORI 3.6.5 CORRECTED SOURCE PACKAGE

WHY 3.6.5?
GitHub already has a v3.6.4 release built from a different/older source tree. Publishing the corrected source as 3.6.4 would be blocked by the repository's duplicate-version release gate, and installed 3.6.4 copies would not detect an equal version. This package therefore uses 3.6.5 so the corrected build can be detected as an update.

PUBLISH STEPS
1. Extract ALL files in this ZIP directly into your existing local ORI-Desktop Git repository folder (the folder that contains .git). Allow the source files to be overwritten.
2. Open that repository folder and double-click PUBLISH_TO_GITHUB.bat.
3. Review the listed changes. Type YES at both prompts only if they are the intended ORI source changes.
4. The script commits and pushes to origin/main. GitHub Actions then runs the 282-test suite, the Windows package checks and the Windows Setup/release workflow. The v3.6.5 installer is published only if those checks pass.
5. Open the repository's Releases page and install ORI-Setup-3.6.5.exe only after the v3.6.5 release and Setup asset are visible.

IMPORTANT
- This ZIP is source code, NOT a Windows installer. It cannot be installed by double-clicking the ZIP.
- Do not delete your existing ORI installation or user data for the update test.
- If the push is rejected, do not force-push. Resolve the Git error and retry normally.
- CI tests passed locally on this package (282 passed), but GitHub's Windows build and installer integration tests still need to run after publishing.
